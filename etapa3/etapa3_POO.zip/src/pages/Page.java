package pages;

public interface Page {
    /**
     * This method prints the page
     */
    String printPage();
}
